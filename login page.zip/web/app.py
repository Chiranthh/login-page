from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# Simulated email data
emails = {
    '1': {'subject': 'internship', 'body': 'The internship has been rescheduled to 3 PM.'},
    '2': {'subject': 'Project', 'body': 'The project is next Monday.'},
    '3': {'subject': 'Seminar', 'body': 'This is a test seminar.'},
    '4': {'subject': 'Presentation', 'body': 'Presentation is great!'}
}

# Home route to display emails
@app.route('/')
def index():
    return render_template('index.html', emails=emails)

# Route to view an email
@app.route('/view/<email_id>')
def view_email(email_id):
    email = emails.get(email_id)
    if email:
        return render_template('view_email.html', email_id=email_id, email=email)
    return redirect(url_for('index'))

# Route to reply to an email
@app.route('/reply/<email_id>', methods=['POST'])
def reply(email_id):
    email = emails.get(email_id)
    if email:
        reply_content = request.form.get('reply')
        # Simulate sending reply
        return render_template('reply_sent.html', email_id=email_id, reply_content=reply_content)
    return redirect(url_for('index'))

# Route to delete an email
@app.route('/delete/<email_id>', methods=['POST'])
def delete(email_id):
    if email_id in emails:
        del emails[email_id]
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)

def on_key_event(e):
    if email_id:
        if e.name == 'r':
            reply_email(email_id)
        elif e.name == 'd':
            delete_email(email_id)
        else:
            print("Invalid key pressed.")
    else:
        print("No email ID selected. Please enter an email ID first.")
    
